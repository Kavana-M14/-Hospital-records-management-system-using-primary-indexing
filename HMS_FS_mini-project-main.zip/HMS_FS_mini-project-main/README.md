# Hospital record Management System using Primary Indexing
Type - Mini Project  
Subject - File Structures  
University - VTU  
Year - 2021  

This application consists of 5 records. This includes the records of 
1.Doctor 2.Nurse 3.Receptionists 4.Ward and 5.Patients.

In the index of the application we provided 5 navigation choices 
1.Admin
2.Doctor
3.Nurse
4.Receptinist and 
0.Exit

### 1.Admin
Here admin can login to application by entering the username and password.
They can Add, Remove and View the Doctor, Nurse, Receptionist and Ward details.

### 2.Doctor
Doctor can directly enter the application. 
Doctors are having Access to View or Search the Patient records.

### 3.Nurse
Nurse can directly enter the application. 
Nurse are having Access to View or Search the Patient records.

### 4.Receptionist
Receptionist can enter the application directly.
Receptionist are going to Register the patients and also they can remove the patient details.

### 0.Exit
By giving this choice user will exit from the application

## Project Demo :

<a href="https://youtu.be/SAVKLLzXy8M" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="@subramanya43" height="30" width="40" /></a>

If you like this project, ⭐ repository.

You can also fork the repository.

Thank You.
